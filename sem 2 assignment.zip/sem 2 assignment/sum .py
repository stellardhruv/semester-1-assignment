a=5
b=5
c=a+b
print(c)



    
