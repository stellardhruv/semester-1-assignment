i=int(input("enter a number"))
fac=1
while i>0:
     fac=fac*i
     i=i-1
     print(fac)
i=int(input("enter a factorial number"))
fact=1
while i>0:
     fact=fact*i
     i=i-1
     print(fact)
