i=5
while i>=0:
    print(i*"*")
    i=i-1
    i=1
while i<=5:
 print(i*"*")
 i=i+1
