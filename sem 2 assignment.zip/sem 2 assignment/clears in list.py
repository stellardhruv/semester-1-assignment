marks=["10,40,50,90"]
marks.clear()
print(marks)
#for loop in python
name=["ram,raja,radha"]
for names in name:
    if name=="radha": 
      break;
    print(name)  