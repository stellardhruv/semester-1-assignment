f=open("C:\Users\Ayushman\Desktop\u\ab.txt","w")
s=f.write("python programming lab \n sec")
print(type(s))
#f.seek()
# print(f.read())
# print(f.tell())
# f.close()

