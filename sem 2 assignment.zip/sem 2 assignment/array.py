import numpy as np
a=[[2,34,5][3,4,5[3,4,5]]]
myarr=np.array(a)


