a=int(input("enter the first number"))
b=int(input("enter the first number"))
operator=input("+,/,-,*")
if operator=="+":
 print(a+b)
elif operator=="/":
    print(a/b)
elif operator=="-":
    print(a-b)
elif operator=="*":
   print(a*b)
else:
    print("invalid operator")           