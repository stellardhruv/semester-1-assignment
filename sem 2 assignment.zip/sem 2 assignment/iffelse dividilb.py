a=int(input("enter a number"))
if (a%3==0 and a%7==0):
    print("number is divisible by both")
elif a%3==0:
    print("number is divisible by 3")
elif a%7==0:
    print("number is divisible by 7 ")  
       
    