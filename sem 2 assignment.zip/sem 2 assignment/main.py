import datetime
current=datetime.datetime.now()
print(current.datatime.timedelta(days=12))
