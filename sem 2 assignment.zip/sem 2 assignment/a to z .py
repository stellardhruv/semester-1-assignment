import string
letters=string.ascii_lowercase
for letter in letters:
    print(letter)