def display(name,rollno):
    print('hello,name,rollno')
def greet(name):
    print('afternoon,ayush')
def add(a,b):
    c=a+b
    print(c)
    
