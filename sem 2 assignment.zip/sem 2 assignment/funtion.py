def add(a,b):
    c=a+b
    print(c)
add(5,10)
#by input
def add(a,b):
    c=a+b
    print(c)
    a=int(input("enter a number"))
    b=int(input("enter a number"))
    add(a,b)