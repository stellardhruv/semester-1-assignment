d={1:'a',2:'b',3:'c'}
print(d .items())
type (d) . items
#pop items 
d={1:'a',2:"f"}
d.popitem()
print(d)
#keys
d={1:'a',2:"f"}
print(d.values())
#shorted
d={1:'a',2:"f"}
a= sorted 
print(a)
print(d)
#




