import p1
p1.greet('abc')
from p1 import*
greet('cd')
add(2,3)