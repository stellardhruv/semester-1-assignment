name=('ayush')
for i in name:
 print(i)
 if i=="y":
    print("ayush ")

for i in range(50):
    print(i)
ayush=("janmbhumi,amethi,agra,")
for i in ayush:
    print(i)
    if (i=="a"):
        print("break for lunch")
