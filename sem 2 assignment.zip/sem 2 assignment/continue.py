for i in range(12):
    if(i==10):
        print("love you ayu")
        continue
    print("5*",i,"=",5*i)
    