#def calculatesum(a,b):
#   c=a+b
 #  print(c)
#a=5
#b=7
#calculatesum(a,b)
#c=3
#d=6
#calculatesum(c,d)
#e=4
#f=4
#calculatesum(e,f)
def calculategraeter(a,b):
   if a>b:
      print("greater")
   else:
      print("smaller")
   a=2
   b=3
   calculategraeter(a,b)

