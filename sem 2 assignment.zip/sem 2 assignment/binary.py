a=42
b=bin(a)
print(b)
a=42
b=oct(a)
print(b)