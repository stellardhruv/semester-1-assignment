banana=200
grapes=300
if banana>=grapes:
    print("i can purchase it ")
else:
    print("i am not purchase it")    