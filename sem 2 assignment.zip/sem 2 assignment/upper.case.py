x=input("enter a string")
if x.isupper():
  print(x.lower ())
if x.islower():
  print(x.upper)