i=int(input("enter the number"))
while(i<=50):
  i=int(input("enter the number"))
  print(i)
i=5
while(i>=0):
    print(i)
    i=i-1