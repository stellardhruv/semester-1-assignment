
#
def add(a,b):
    c=(a,b)
    return(c)
a=int(input("enter a number"))
b=int(input("enter a number"))
add(a,b)