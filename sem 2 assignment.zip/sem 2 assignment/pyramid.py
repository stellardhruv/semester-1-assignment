n=int(input("enter a number of row"))
for i in range(n):
 for j in range(n-i-1) :
  print()
for j in range(n+1):
 print("*")
 print()
