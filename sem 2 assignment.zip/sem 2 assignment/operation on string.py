#s="'hello'"
#print(s)
#a=int(input("enter a string"))
#print(a)
#print(type(a))
#s="'hello class secion u'"
#print(s)
#s="hello world"
#print( s.count("w",3))
#S=("hello class")
#print (S.upper())
#S="anshuman"
#print(S.capitalize())
#S="hello babu"
#print(S.swapcase())
#a='123'
#print(a.isdigit())
#S="hello ayush"
#print(S.split(""))
a=(input("check the condition"))
if a == a.upper():
    print(a,"condition is uper")
elif a==a.lower():
    print(a,"condition is lower")
elif a==a.title():
    print(a,"conditon is tittle")
else:
     print(a,"conditn is digit")
