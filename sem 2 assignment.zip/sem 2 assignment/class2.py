import random
l=[48,100,74,44]
random.choice(l)
print(l )
