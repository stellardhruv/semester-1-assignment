S='hello'.split
L=list(S)
print(L)
#list comprihention
#print([x for x in range (1,11)if(x%2==0)])



