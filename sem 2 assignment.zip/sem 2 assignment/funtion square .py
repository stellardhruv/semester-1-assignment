
def sqauare(num):
  print(num/2)
numner=int(input("enter a number"))
print(sqauare(numner))
if numner==numner:
  print("even")
else:
  print("oddd")

