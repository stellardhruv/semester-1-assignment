a=[]
size=int(input("enter a number i want "))
for i in range(size):
   Val=int(input("enter a number"))
a.append (Val)
print(a)