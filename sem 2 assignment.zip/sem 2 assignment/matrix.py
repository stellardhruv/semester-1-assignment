a=int(input("enter a number"))
for i in range (1,a+1,1):
    for j in range(1,a+1,1):
     print(j,end="")
    print("")
   
