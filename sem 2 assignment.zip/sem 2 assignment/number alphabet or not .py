ch=input("enter a alphabet")
if ch>="a" and ch<="z":
    print(ch,"is alphabet")
else:
    print(ch,"number is not albhabet")