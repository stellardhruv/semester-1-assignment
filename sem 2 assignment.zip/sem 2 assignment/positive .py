a=int(input("enter a number"))
if a>0:
    print("number is positive")
elif a<0:
    print("number is negative")    
elif a==0:
    print("number is 0")    