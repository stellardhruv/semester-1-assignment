import math
print(math. pow)