for i in range(12):
      print("5*",i,"=",5*i)
      if i==10:
        break
print("hello world ")    