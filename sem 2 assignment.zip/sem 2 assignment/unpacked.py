x=1,2,3,4
a,b,*c=x
print(a,b,c)