import math
print(pow(4,5))