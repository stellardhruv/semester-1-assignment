number=int(input('enter the value of number'))
if number<0:
 print("number is negative")
elif number==0:
 print("number is zero")
else:
  print("number is positive")
