
S='hello class setion u'
SI=S[::-1]
print(SI)
S='hello class setion u'
SI=S[3:-2:1]
print(SI)
S='hello class setion u'.split
SI=S[3:2:-1]
print(SI)
#touple
L=[1,10,6,'abc']
L.append(40)
print(L)
#EXTEND
L=['Hllo']
L.extend
print(L)

