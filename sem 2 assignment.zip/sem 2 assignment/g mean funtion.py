def calculategmean(a,b):
    gmean=(a*b/a+b)
    print(gmean)

def isgreater(a,b):
    if a>b:
     print("first number is  greater")
    else:
      print('second number is graeter')  
def islessor(a,b):
    pass       
a=5
b=10
isgreater(a,b)   
calculategmean(a,b)
c=12
d=15
isgreater(a,b)
calculategmean(c,d)    
