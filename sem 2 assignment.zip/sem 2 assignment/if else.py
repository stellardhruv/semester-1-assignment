a=int(input('enter the age '))
print("your age is:",a)
if (a>18):
   print ("you can drive")
else:
   print("you can not drive")  
print("wow to mat chala thuk jayega bhai")    