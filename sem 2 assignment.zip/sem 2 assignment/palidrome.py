a=input('''enter string:''')
b=a[-1::-1]
if a==b:
    print("string pelidrome")
else:
     print("string is not pelidrome")
