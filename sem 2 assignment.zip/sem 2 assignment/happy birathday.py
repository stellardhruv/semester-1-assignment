for i in range(12):
    print(i)
print("happy birahtday versa")    